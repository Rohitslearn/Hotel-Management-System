package com.demo.model;

import java.util.List;

public class GuestList {

	private List<Guest> allGuest;

	public List<Guest> getAllGuest() {
		return allGuest;
	}

	public void setAllGuest(List<Guest> allGuest) {
		this.allGuest = allGuest;
	}

}
